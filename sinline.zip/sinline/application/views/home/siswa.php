<div class="well">
                	<table class="table table-striped" >
                		<tr>
                			<th colspan="3" class="text-center"><h4>IDENTITAS</h4></th>
                		</tr>
                		<tr>
                			<td width="35%"></td>
                			<td class="text-left" width="15%">Nis</td>
                			<td class="text-left"> : <?php echo $info->nis;?></td>
                		</tr>
                		<tr>
                			<td></td>
                			<td>Nama</td>
                			<td class="text-left"> : <?php echo $info->nama; ?></td>
                		</tr>
                		<tr>
                			<td></td>
                			<td>Jurusan</td>
                			<td class="text-left"> : <?php echo $info->jurusan; ?></td>
                		</tr>
                		<tr>
                			<td></td>
                			<td>Angkatan</td>
                			<td class="text-left"> : <?php echo $info->angkatan; ?></td>
                		</tr>
                		<tr>
                			<td></td>
                			<td>Kontak</td>
                			<td class="text-left"> : <?php echo $info->kontak; ?></td>
                		</tr>
                	</table>

                </div>