<div class="well">
                	<table class="table table-striped" >
                		<tr>
                			<th colspan="3" class="text-center"><h4>IDENTITAS</h4></th>
                		</tr>
                		<tr>
                			<td width="35%"></td>
                			<td class="text-left" width="15%">ID GURU</td>
                			<td class="text-left"> : <?php echo $info->id_guru;?></td>
                		</tr>

                                <tr>
                                        <td></td>
                                        <td>Nama</td>
                                        <td class="text-left"> : <?php echo $info->nama_guru; ?></td>
                                </tr>
                		<tr>
                			<td></td>
                			<td>Status</td>
                			<td class="text-left"> : Guru</td>
                		</tr>
                		<tr>
                			<td></td>
                			<td>Kontak</td>
                			<td class="text-left"> : <?php echo $info->kontak; ?></td>
                		</tr>
                	</table>

                </div>