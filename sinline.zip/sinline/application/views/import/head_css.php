
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<link rel="shortcut icon" href="<?php echo base_url('bootstrap/favicon.ico') ?>"/>
<link href="<?php echo base_url('bootstrap/css/bootstrap-theme.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>" rel="stylesheet">
<script src="<?php echo base_url('bootstrap/js/jquery-1.11.1.min.js') ?>"></script>
<script src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
