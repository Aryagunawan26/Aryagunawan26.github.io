<div class="foother text-center ">
    <p class="pull-right">Repost by <a href="https://stokcoding.com/" title="StokCoding.com" target="_blank">StokCoding.com</a> | <a href="#">Ke Atas</a></p>
</div>